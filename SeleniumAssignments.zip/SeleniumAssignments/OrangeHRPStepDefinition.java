package StepDefinations;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.qa.pages.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class OrangeHRPStepDefinition {
	OrangeHrpPages OrangeOR;
	WebDriver Driver;
	
	@Given("^User is on OrangeHRP web page")
	public void User_Is_On_OrangeHRP_WebPage() {
		System.setProperty("webdriver.chrome.driver", "C:\\soft\\Selenium Driver\\chromedriver.exe");
		ChromeOptions co = new ChromeOptions();
		Driver 	= new ChromeDriver(co);
		Driver.get("https://opensource-demo.orangehrmlive.com/");
		OrangeOR = new OrangeHrpPages(Driver);
	}

	@Then("^User Enters the username and password$")
	public void User_Enters_The_Username_And_Password() {
	System.out.println(Driver.getTitle());
	OrangeOR.settextforUserName("Admin");
	OrangeOR.setTextforPassword("admin123");
	OrangeOR.setStaySignedInClick();
	}

	@When("^Dashboard page is displayed$")
	public void dashboard_page_is_displayed()  {
	   OrangeOR.getDashBoardisplayed();
	   System.out.println(Driver.getCurrentUrl());
	}

	@When("^User clicks on Admin menu$")
	public void click_on_Admin_menu()  {
		OrangeOR.settoAdminMenu();
	}


	@Then("^User clicks on Job$")
	public void User_Clicks_on_Job()  {
		OrangeOR.settoJobMenu();
	    
	}

	@Then("^validate text Job Title$")
	public void validate_text_Job_Title()  {
		
		OrangeOR.settoJobTitle();
		OrangeOR.getJobTitle();
		
		
	@Then("^Close the browser$")
	public void close_the_browser() {
	Driver.close();
	Driver.quit();
	}


}